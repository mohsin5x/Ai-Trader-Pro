# -*- mode: python ; coding: utf-8 -*-
#
# PyInstaller spec for AI Trader Pro.
#
# Build (Windows, from project root):
#     pip install -r requirements.txt
#     pyinstaller packaging/AI_Trader_Pro.spec --noconfirm
#
# Output: dist/AI Trader Pro/AI Trader Pro.exe
# Then run packaging/installer.iss in Inno Setup for final Setup.exe.

import sys
from pathlib import Path

block_cipher = None
PROJECT_ROOT = Path(SPECPATH).parent

# Include all runtime data files
datas = [
    (str(PROJECT_ROOT / "assets"),      "assets"),
    (str(PROJECT_ROOT / "config"),      "config"),
    (str(PROJECT_ROOT / "data"),        "data"),
    (str(PROJECT_ROOT / ".env.example"), "."),
    (str(PROJECT_ROOT / "config.json"), "."),
]

# Only include data directory if it exists
import os
if not os.path.exists(str(PROJECT_ROOT / "data")):
    datas = [d for d in datas if "data" not in d[0]]

a = Analysis(
    [str(PROJECT_ROOT / "main.py")],
    pathex=[str(PROJECT_ROOT)],
    binaries=[],
    datas=datas,
    hiddenimports=[
        # Core UI
        "customtkinter",
        "customtkinter.windows",
        "customtkinter.windows.widgets",
        "customtkinter.windows.widgets.core_widget_classes",
        "PIL",
        "PIL._tkinter_finder",
        "PIL.Image",
        "PIL.ImageGrab",
        "PIL.ImageTk",
        # Data & networking
        "pandas",
        "pandas.core",
        "pandas.core.arrays",
        "numpy",
        "numpy.core",
        "requests",
        "requests.adapters",
        "requests.auth",
        # Config
        "dotenv",
        "python_dotenv",
        # Database
        "sqlite3",
        # Standard library (sometimes missed by PyInstaller)
        "logging.handlers",
        "concurrent.futures",
        "threading",
        "csv",
        "hashlib",
        "json",
        "webbrowser",
        "tkinter",
        "tkinter.filedialog",
        "tkinter.messagebox",
        # Optional deps - include if available
        "psutil",
        "plyer",
        "plyer.platforms",
        "plyer.platforms.win",
        "plyer.platforms.win.notification",
        "openpyxl",
        # App modules
        "core.app_state",
        "config.settings",
        "utils.logger",
        "utils.error_handler",
        "utils.notifications",
        "utils.path_manager",
        "models.signal_model",
        "models.chart_model",
        "models.strategy_result",
        "services.crypto_service",
        "services.market_analyzer",
        "services.ai_engine",
        "services.signal_engine",
        "services.market_scanner",
        "services.paper_trading_engine",
        "services.paper_trading_db",
        "services.paper_trading_analytics",
        "services.signal_storage",
        "services.history_service",
        "services.chart_overlays",
        "services.provider_settings",
        "services.leverage_manager",
        "services.notification_center",
        "services.smc_analysis",
        "services.market_data_provider",
        "services.universal_free_provider",
        "ui.theme",
        "ui.components",
        "ui.main_window",
        "ui.chart_widget",
        "ui.coin_selector",
        "ui.ai_panel",
        "ui.trade_panel",
        "ui.trade_journal_panel",
        "ui.signal_engine_panel",
        "ui.signal_history_panel",
        "ui.algo_trading_panel",
        "ui.paper_trading_panel",
        "ui.paper_trading_history_panel",
        "ui.settings_panel",
        "ui.notification_bell",
        "ui.news_panel",
        "ui.news_page",
        "ui.watchlist_page",
        "ui.market_sessions_page",
        "ui.about_dialog",
        "ui.splash_screen",
        "ui.status_bar",
        "ui.sidebar",
        "ui.watchlist",
        "ui.watchlist_panel",
        "ui.order_panel",
        "ui.strategy_panel",
        "ui.trade_journal_panel",
        "ui.risk_tools_panel",
        "services.ai_service",
        "services.data_feed_factory",
        "services.indicator_service",
        "services.mt_data_service",
        "services.trade_service",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        "MetaTrader5",   # no MT5 dependency
        "tvDatafeed",    # optional — only needed for Universal Free provider
        "ccxt",          # optional — only needed for Universal Free provider
        "matplotlib",    # not used (pure tkinter canvas chart)
        "scipy",
        "sklearn",
        "tensorflow",
        "torch",
        "unittest",
        "test",
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="AI Trader Pro",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    console=False,           # windowed — no terminal popup on Windows
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=str(PROJECT_ROOT / "assets" / "app_icon.ico")
         if (PROJECT_ROOT / "assets" / "app_icon.ico").exists() else None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="AI Trader Pro",
)
