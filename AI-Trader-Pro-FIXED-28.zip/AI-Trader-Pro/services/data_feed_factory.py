"""
services/data_feed_factory.py
================================
Task 2: DataFeedFactory. Turns a settings dict (or config.json, via
services/provider_settings.py) into a ready-to-use MarketDataProvider
instance -- "Default (Free)", MT5, or Twelve Data.
"""

from typing import Optional

from config import settings as app_settings
from services.market_data_provider import RateLimiter, TwelveDataProvider
from services.universal_free_provider import UniversalFreeProvider
from services.mt5_provider import MT5Provider
from utils.logger import logger


class DataFeedFactory:
    """settings_dict shape (see services/provider_settings.py):
        {"provider_type": "Default" | "MT5" | "TwelveData", "api_key": "..."}
    """

    @staticmethod
    def get_provider(settings_dict: dict):
        provider_type = (settings_dict or {}).get("provider_type", "Default")

        if provider_type == "Default":
            return UniversalFreeProvider()

        if provider_type == "MT5":
            # Symbol overrides: map the app's display labels to your broker's MT5 symbol names.
            # Many brokers suffix crypto CFDs differently — adjust to match yours.
            # Common variants: BTCUSD, BTCUSDm, BTC/USD, BITCOIN, XBTUSDT
            # Leave the dict empty ({}) to pass symbols through unchanged.
            mt5_overrides = {
                # Crypto — uncomment and adjust if your broker uses different names:
                # "BTC": "BTCUSDm",
                # "ETH": "ETHUSDm",
                # "BNB": "BNBUSDm",
            }
            return MT5Provider(symbol_overrides=mt5_overrides)

        if provider_type == "TwelveData":
            # ============================================================
            # >>> PUT YOUR TWELVE DATA API KEY HERE <<<
            # Preferred: set it via Settings (this is settings_dict["api_key"],
            # persisted by services.provider_settings.save_settings) or in
            # your .env file as TWELVE_DATA_API_KEY=your_key_here.
            # Falls back to the .env value if Settings hasn't set one yet,
            # so existing .env-based setups keep working unchanged.
            # ============================================================
            api_key: Optional[str] = settings_dict.get("api_key") or app_settings.TWELVE_DATA_API_KEY
            if not api_key:
                logger.warning("[DataFeedFactory] TwelveData selected but no API key found in Settings or .env -- falling back to Default (Free).")
                return UniversalFreeProvider()

            limiter = RateLimiter(app_settings.TWELVE_DATA_RATE_LIMIT, 60)
            return TwelveDataProvider(api_key, limiter, limiter)

        logger.warning(f"[DataFeedFactory] Unknown provider_type '{provider_type}' -- falling back to Default (Free).")
        return UniversalFreeProvider()
