"""
services/mt5_provider.py
==========================
Optional MetaTrader 5 data source -- ONLY instantiated if the user
explicitly picks "MT5" in Settings. The app's default, out-of-the-box
experience is UniversalFreeProvider (services/universal_free_provider.py);
this file changes nothing about that.

Requires the `MetaTrader5` package AND a running, logged-in MT5
terminal on the same machine -- both are the user's own choice/setup,
not a hidden app requirement. If either isn't available, every method
here fails gracefully (returns None / "Data unavailable") rather than
crashing the app or fabricating a price, same as every other provider.
"""

from typing import Dict, List, Optional
import threading

import pandas as pd

from services.market_data_provider import MarketDataProvider, RateLimiter
from utils.logger import logger

try:
    import MetaTrader5 as mt5
    _MT5_AVAILABLE = True
    _MT5_IMPORT_ERROR = None
except Exception as e:
    _MT5_AVAILABLE = False
    mt5 = None
    _MT5_IMPORT_ERROR = f"{type(e).__name__}: {e}"

_MT5_TIMEFRAME_MAP = {
    "1m": "TIMEFRAME_M1", "5m": "TIMEFRAME_M5", "15m": "TIMEFRAME_M15",
    "30m": "TIMEFRAME_M30", "1h": "TIMEFRAME_H1", "4h": "TIMEFRAME_H4", "1d": "TIMEFRAME_D1",
}


class MT5Provider(MarketDataProvider):
    """Reads live prices/candles from a locally running MetaTrader 5
    terminal. Symbol labels are passed straight through to MT5 (e.g.
    "EURUSD", "XAUUSD") -- rename via `symbol_overrides` if your
    broker uses different tickers (e.g. "EURUSD.m")."""

    name = "mt5"
    display_name = "MetaTrader 5"

    # Candle data TTL: MT5 candles don't change faster than the timeframe itself;
    # caching for 2s prevents redundant COM calls that cause UI lag spikes.
    _CANDLE_TTL = 2.0   # seconds
    _QUOTE_TTL  = 1.0   # seconds (sub-second ticks not needed for this UI)

    def __init__(self, symbol_overrides: Optional[Dict[str, str]] = None):
        super().__init__(api_key=None, quote_limiter=RateLimiter(120, 60), candle_limiter=RateLimiter(120, 60))
        self._symbol_overrides = symbol_overrides or {}
        self._init_lock = threading.Lock()
        self._initialized = False
        self._logged_missing_package = False
        
        # --- ASYNC FIX: Prevents thread spamming when waiting for connection ---
        self._init_thread_active = False 
        
        self._candle_cache: dict = {}   
        self._quote_cache:  dict = {}   
        self._cache_lock = threading.Lock()
        self._configured_cache: Optional[bool] = None
        self._configured_cache_ts: float = 0.0
        self._CONFIGURED_CACHE_TTL = 5.0   

    def _symbol_for(self, label: str) -> str:
        return self._symbol_overrides.get(label, label.replace("/", ""))

    def _ensure_initialized(self) -> bool:
        """
        Checks initialization state instantly. If uninitialized, it spawns
        a background thread to perform the blocking COM network handshake 
        instead of starving the main GUI thread.
        """
        if not _MT5_AVAILABLE:
            if not self._logged_missing_package:
                logger.warning(f"[MT5Provider] MetaTrader5 package unavailable ({_MT5_IMPORT_ERROR}) -- run `pip install MetaTrader5`.")
                self._logged_missing_package = True
            return False
            
        if self._initialized:
            return True
            
        # Non-blocking async check: spawn thread without hanging UI
        if not self._init_thread_active:
            self._init_thread_active = True
            threading.Thread(target=self._background_initialize_worker, daemon=True).start()
            
        return self._initialized

    def _background_initialize_worker(self):
        """
        Asynchronous network connection worker dispatched for MT5.
        Runs safely in the background so the UI never freezes.
        """
        with self._init_lock:
            try:
                logger.info("[MT5Provider] Asynchronous network connection worker dispatched for MT5.")
                if self._initialized:
                    return
                success = bool(mt5.initialize())
                if not success:
                    logger.warning(f"[MT5Provider] mt5.initialize() failed: {mt5.last_error()}")
                self._initialized = success
            except Exception as e:
                logger.critical(f"[MT5Provider] Asynchronous worker breakdown: {e}")
                self._initialized = False
            finally:
                import time
                self._configured_cache = self._initialized
                self._configured_cache_ts = time.time()
                self._init_thread_active = False

    def is_configured(self) -> bool:
        import time as _t
        now = _t.time()
        if self._configured_cache is not None and now - self._configured_cache_ts < self._CONFIGURED_CACHE_TTL:
            return self._configured_cache
        result = self._ensure_initialized()
        self._configured_cache = result
        self._configured_cache_ts = now
        return result

    def get_quotes(self, labels: List[str]) -> Dict[str, Optional[dict]]:
        import time as _time
        now = _time.time()
        result = {label: None for label in labels}

        if not self._ensure_initialized():
            # Return cached quotes when terminal is temporarily unavailable
            with self._cache_lock:
                for label in labels:
                    entry = self._quote_cache.get(label)
                    if entry and now - entry[0] < 30.0:  # stale ok for 30s on disconnect
                        result[label] = entry[1]
            return result

        if not self.quote_limiter.allow(cost=max(1, len(labels))):
            # Rate limited -- serve from cache
            with self._cache_lock:
                for label in labels:
                    entry = self._quote_cache.get(label)
                    if entry:
                        result[label] = entry[1]
            return result

        for label in labels:
            # Check per-symbol quote TTL first
            with self._cache_lock:
                entry = self._quote_cache.get(label)
                if entry and now - entry[0] < self._QUOTE_TTL:
                    result[label] = entry[1]
                    continue

            mt5_symbol = self._symbol_for(label)
            try:
                tick = mt5.symbol_info_tick(mt5_symbol)
                if tick is None:
                    continue
                q = {
                    "price": float(tick.last or tick.bid or tick.ask),
                    "bid": float(tick.bid), "ask": float(tick.ask),
                    "time": float(tick.time),
                }
                result[label] = q
                with self._cache_lock:
                    self._quote_cache[label] = (now, q)
            except Exception as e:
                logger.warning(f"[MT5Provider] symbol_info_tick({mt5_symbol}) failed: {e}")
                # Serve stale cache on error
                with self._cache_lock:
                    entry = self._quote_cache.get(label)
                    if entry:
                        result[label] = entry[1]
        return result

    def get_candles(self, label: str, timeframe: str, outputsize: int = 300) -> Optional[pd.DataFrame]:
        if not self._ensure_initialized():
            return None
        tf_attr = _MT5_TIMEFRAME_MAP.get(timeframe)
        if not tf_attr:
            return None

        cache_key = f"{label}:{timeframe}:{outputsize}"
        now = __import__('time').time()

        # Return cached candles if still fresh (avoids COM lag on every tick)
        with self._cache_lock:
            entry = self._candle_cache.get(cache_key)
            if entry and now - entry[0] < self._CANDLE_TTL:
                return entry[1].copy()

        if not self.candle_limiter.allow():
            # Rate limited -- return stale cache if available rather than None
            with self._cache_lock:
                entry = self._candle_cache.get(cache_key)
                if entry:
                    return entry[1].copy()
            return None

        mt5_symbol = self._symbol_for(label)
        try:
            rates = mt5.copy_rates_from_pos(mt5_symbol, getattr(mt5, tf_attr), 0, outputsize)
            if rates is None or len(rates) == 0:
                return None
            df = pd.DataFrame(rates)
            df["timestamp"] = pd.to_datetime(df["time"], unit="s")
            df = df.rename(columns={"tick_volume": "volume"})
            df = df[["timestamp", "open", "high", "low", "close", "volume"]].sort_values("timestamp").reset_index(drop=True)
            with self._cache_lock:
                self._candle_cache[cache_key] = (now, df)
            return df.copy()
        except Exception as e:
            logger.warning(f"[MT5Provider] copy_rates_from_pos({mt5_symbol}) failed: {e}")
            # Return stale cache on error -- better than blanking the chart
            with self._cache_lock:
                entry = self._candle_cache.get(cache_key)
                if entry:
                    return entry[1].copy()
            return None

    def shutdown(self):
        with self._cache_lock:
            self._candle_cache.clear()
            self._quote_cache.clear()
        if _MT5_AVAILABLE and self._initialized:
            try:
                mt5.shutdown()
            except Exception:
                pass
            self._initialized = False